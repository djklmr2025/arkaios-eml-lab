use std::collections::{HashMap, HashSet};
use std::env;
use std::f64::consts::{FRAC_PI_2, PI};
use std::process;
use std::sync::Arc;
use std::time::Instant;
use rayon::prelude::*;

const GLAISHER: f64 = 1.282_427_129_100_622_6;
const EULER_GAMMA: f64 = 0.577_215_664_901_532_9;

#[derive(Clone, Copy, Debug)]
struct C {
    re: f64,
    im: f64,
}

impl C {
    fn new(re: f64, im: f64) -> Self {
        Self { re, im }
    }
    fn real(x: f64) -> Self {
        Self { re: x, im: 0.0 }
    }
    fn i() -> Self {
        Self { re: 0.0, im: 1.0 }
    }
    fn is_finite(self) -> bool {
        self.re.is_finite() && self.im.is_finite()
    }
    fn abs(self) -> f64 {
        self.re.hypot(self.im)
    }
    fn arg(self) -> f64 {
        self.im.atan2(self.re)
    }
    fn add(self, o: C) -> C {
        C::new(self.re + o.re, self.im + o.im)
    }
    fn sub(self, o: C) -> C {
        C::new(self.re - o.re, self.im - o.im)
    }
    fn mul(self, o: C) -> C {
        C::new(self.re * o.re - self.im * o.im, self.re * o.im + self.im * o.re)
    }
    fn div(self, o: C) -> Option<C> {
        let den = o.re * o.re + o.im * o.im;
        if den == 0.0 {
            return None;
        }
        Some(C::new(
            (self.re * o.re + self.im * o.im) / den,
            (self.im * o.re - self.re * o.im) / den,
        ))
    }
    fn neg(self) -> C {
        C::new(-self.re, -self.im)
    }
    fn exp(self) -> C {
        let ea = self.re.exp();
        C::new(ea * self.im.cos(), ea * self.im.sin())
    }
    fn ln(self) -> Option<C> {
        let r = self.abs();
        if r == 0.0 {
            return None;
        }
        Some(C::new(r.ln(), self.arg()))
    }
    fn sqrt(self) -> C {
        let r = self.abs();
        let t = self.arg() / 2.0;
        let m = r.sqrt();
        C::new(m * t.cos(), m * t.sin())
    }
    fn sin(self) -> C {
        C::new(self.re.sin() * self.im.cosh(), self.re.cos() * self.im.sinh())
    }
    fn cos(self) -> C {
        C::new(self.re.cos() * self.im.cosh(), -self.re.sin() * self.im.sinh())
    }
    fn tan(self) -> Option<C> {
        self.sin().div(self.cos())
    }
    fn sinh(self) -> C {
        C::new(self.re.sinh() * self.im.cos(), self.re.cosh() * self.im.sin())
    }
    fn cosh(self) -> C {
        C::new(self.re.cosh() * self.im.cos(), self.re.sinh() * self.im.sin())
    }
    fn tanh(self) -> Option<C> {
        self.sinh().div(self.cosh())
    }
    fn pow(self, w: C) -> Option<C> {
        if self.re == 0.0 && self.im == 0.0 {
            if w.re == 0.0 && w.im == 0.0 {
                return Some(C::real(1.0));
            }
            if w.im == 0.0 && w.re > 0.0 {
                return Some(C::real(0.0));
            }
            return None;
        }
        Some(w.mul(self.ln()?).exp())
    }
    fn asin(self) -> Option<C> {
        let i = C::i();
        let one = C::real(1.0);
        let iz = i.mul(self);
        let inside = one.sub(self.mul(self)).sqrt();
        Some(i.neg().mul(iz.add(inside).ln()?))
    }
    fn acos(self) -> Option<C> {
        Some(C::real(FRAC_PI_2).sub(self.asin()?))
    }
    fn atan(self) -> Option<C> {
        let i = C::i();
        let one = C::real(1.0);
        let l1 = one.sub(i.mul(self)).ln()?;
        let l2 = one.add(i.mul(self)).ln()?;
        Some(C::new(0.0, 0.5).mul(l1.sub(l2)))
    }
    fn asinh(self) -> Option<C> {
        let one = C::real(1.0);
        self.add(self.mul(self).add(one).sqrt()).ln()
    }
    fn acosh(self) -> Option<C> {
        let one = C::real(1.0);
        self.add(self.add(one).sqrt().mul(self.sub(one).sqrt())).ln()
    }
    fn atanh(self) -> Option<C> {
        let one = C::real(1.0);
        Some(one.add(self).ln()?.sub(one.sub(self).ln()?).mul(C::real(0.5)))
    }
}

type F = Arc<dyn Fn(&[C]) -> Option<C> + Send + Sync>;

#[derive(Clone)]
struct Cand {
    expr: String,
    f: F,
    deps: u8,
}

struct GenOutput {
    pool: Vec<Cand>,
    discarded_by_cap: usize,
    total_unique_all_deps: usize,
}

fn empty_gen_output() -> GenOutput {
    GenOutput {
        pool: Vec::new(),
        discarded_by_cap: 0,
        total_unique_all_deps: 0,
    }
}

#[derive(Clone)]
struct Unary {
    f: Arc<dyn Fn(C) -> Option<C> + Send + Sync>,
}
#[derive(Clone)]
struct Binary {
    f: Arc<dyn Fn(C, C) -> Option<C> + Send + Sync>,
    commutative: bool,
}
#[derive(Clone)]
struct Ternary {
    f: Arc<dyn Fn(C, C, C) -> Option<C> + Send + Sync>,
}

fn near(a: C, b: C) -> bool {
    a.sub(b).abs() <= 16.0 * f64::EPSILON * (1.0 + a.abs() + b.abs())
}
fn qkey(v: C) -> (i64, i64) {
    ((v.re * 1e10).round() as i64, (v.im * 1e10).round() as i64)
}

fn sample_inputs(arity: usize) -> Vec<Vec<C>> {
    let s1 = vec![
        C::real(-1.3),
        C::real(-0.4),
        C::real(0.3),
        C::real(0.9),
        C::real(2.1),
        C::new(0.8, 0.2),
    ];
    match arity {
        0 => vec![vec![]],
        1 => s1.into_iter().map(|x| vec![x]).collect(),
        2 => vec![
            vec![C::real(EULER_GAMMA), C::real(GLAISHER)],
            vec![C::real(1.3), C::real(0.7)],
            vec![C::new(0.8, 0.2), C::real(1.1)],
            vec![C::real(-0.7), C::new(0.4, 0.9)],
        ],
        _ => vec![
            vec![C::real(0.8), C::real(1.2), C::real(2.3)],
            vec![C::new(0.6, 0.1), C::real(0.9), C::new(1.1, -0.2)],
        ],
    }
}

fn arg_permutations(arity: usize) -> Vec<Vec<usize>> {
    fn backtrack(
        arity: usize,
        used: &mut [bool],
        cur: &mut Vec<usize>,
        out: &mut Vec<Vec<usize>>,
    ) {
        if cur.len() == arity {
            out.push(cur.clone());
            return;
        }
        for i in 0..arity {
            if used[i] {
                continue;
            }
            used[i] = true;
            cur.push(i);
            backtrack(arity, used, cur, out);
            cur.pop();
            used[i] = false;
        }
    }

    if arity == 0 {
        return vec![vec![]];
    }
    let mut used = vec![false; arity];
    let mut cur = Vec::with_capacity(arity);
    let mut out = Vec::new();
    backtrack(arity, &mut used, &mut cur, &mut out);
    out
}

fn signature(c: &Cand, arity: usize, quotient_var_permutations: bool) -> Option<Vec<(i64, i64)>> {
    let samples = sample_inputs(arity);
    if !quotient_var_permutations || arity <= 1 {
        let mut out = Vec::new();
        for args in samples {
            let v = (c.f)(&args)?;
            if !v.is_finite() {
                return None;
            }
            out.push(qkey(v));
        }
        return Some(out);
    }

    let perms = arg_permutations(arity);
    let mut best: Option<Vec<(i64, i64)>> = None;
    for perm in perms {
        let mut out = Vec::new();
        for args in &samples {
            let mut reordered: Vec<C> = Vec::with_capacity(arity);
            for &idx in &perm {
                reordered.push(args[idx]);
            }
            let v = (c.f)(&reordered)?;
            if !v.is_finite() {
                return None;
            }
            out.push(qkey(v));
        }
        if best.as_ref().is_none_or(|b| out < *b) {
            best = Some(out);
        }
    }
    best
}

fn unary_ops() -> Vec<(&'static str, Arc<dyn Fn(C) -> Option<C> + Send + Sync>)> {
    vec![
        ("Half", Arc::new(|x| Some(x.mul(C::real(0.5))))),
        ("Minus", Arc::new(|x| Some(x.neg()))),
        ("Log", Arc::new(|x| x.ln())),
        ("Exp", Arc::new(|x| Some(x.exp()))),
        ("Inv", Arc::new(|x| C::real(1.0).div(x))),
        ("Sqrt", Arc::new(|x| Some(x.sqrt()))),
        ("Sqr", Arc::new(|x| Some(x.mul(x)))),
        ("Cosh", Arc::new(|x| Some(x.cosh()))),
        ("Cos", Arc::new(|x| Some(x.cos()))),
        ("Sinh", Arc::new(|x| Some(x.sinh()))),
        ("Sin", Arc::new(|x| Some(x.sin()))),
        ("Tanh", Arc::new(|x| x.tanh())),
        ("Tan", Arc::new(|x| x.tan())),
        ("ArcSinh", Arc::new(|x| x.asinh())),
        ("ArcTanh", Arc::new(|x| x.atanh())),
        ("ArcSin", Arc::new(|x| x.asin())),
        ("ArcCos", Arc::new(|x| x.acos())),
        ("ArcTan", Arc::new(|x| x.atan())),
        ("ArcCosh", Arc::new(|x| x.acosh())),
    ]
}

fn binary_ops() -> Vec<(&'static str, bool, Arc<dyn Fn(C, C) -> Option<C> + Send + Sync>)> {
    vec![
        ("Plus", true, Arc::new(|a, b| Some(a.add(b)))),
        ("Times", true, Arc::new(|a, b| Some(a.mul(b)))),
        ("Subtract", false, Arc::new(|a, b| Some(a.sub(b)))),
        ("Divide", false, Arc::new(|a, b| a.div(b))),
        ("Power", false, Arc::new(|a, b| a.pow(b))),
        ("Log", false, Arc::new(|base, x| x.ln()?.div(base.ln()?))),
    ]
}

fn ternary_ops() -> Vec<(&'static str, Arc<dyn Fn(C, C, C) -> Option<C> + Send + Sync>)> {
    vec![("FSD", Arc::new(|a, b, c| a.sub(b).div(c)))]
}

fn generation_seed_constants() -> Vec<(&'static str, C)> {
    vec![
        ("0", C::real(0.0)),
        ("Pi", C::real(PI)),
        ("E", C::real(std::f64::consts::E)),
        ("I", C::i()),
        ("1", C::real(1.0)),
        ("-1", C::real(-1.0)),
        ("2", C::real(2.0)),
    ]
}

fn generate_candidates(
    arity: usize,
    gen_k: usize,
    max_keep: usize,
    require_full_deps: bool,
    quotient_var_permutations: bool,
    gen_filter: &GenLanguageFilter,
) -> GenOutput {
    if gen_k == 0 {
        return empty_gen_output();
    }
    let mut levels: Vec<Vec<Cand>> = vec![vec![]; gen_k + 1];
    let mut seen: HashMap<Vec<(i64, i64)>, Cand> = HashMap::new();
    let mut discarded_by_cap = 0usize;
    for var_i in 0..arity {
        let mut deps = 0u8;
        deps |= 1 << var_i;
        let f = Arc::new(move |args: &[C]| Some(args[var_i]));
        let c = Cand {
            expr: format!("v{var_i}"),
            f,
            deps,
        };
        if let Some(sig) = signature(&c, arity, quotient_var_permutations) {
            seen.insert(sig, c.clone());
            levels[1].push(c);
        }
    }
    for (n, v) in generation_seed_constants() {
        if !gen_filter.allow_const(n) {
            continue;
        }
        let vv = v;
        let c = Cand {
            expr: n.to_string(),
            f: Arc::new(move |_| Some(vv)),
            deps: 0,
        };
        if let Some(sig) = signature(&c, arity, quotient_var_permutations) {
            seen.insert(sig, c.clone());
            levels[1].push(c);
        }
    }

    for k in 2..=gen_k {
        let mut next: Vec<Cand> = Vec::new();
        for u in unary_ops() {
            if !gen_filter.allow_unary(u.0) {
                continue;
            }
            for a in &levels[k - 1] {
                let f0 = a.f.clone();
                let op = u.1.clone();
                let cand = Cand {
                    expr: format!("{}({})", u.0, a.expr),
                    f: Arc::new(move |args| op(f0(args)?) ),
                    deps: a.deps,
                };
                if let Some(sig) = signature(&cand, arity, quotient_var_permutations) {
                    if !seen.contains_key(&sig) {
                        seen.insert(sig, cand.clone());
                        next.push(cand);
                    }
                }
            }
        }
        for b in binary_ops() {
            if !gen_filter.allow_binary(b.0) {
                continue;
            }
            for lk in 1..k - 1 {
                let rk = k - 1 - lk;
                for a in &levels[lk] {
                    for bb in &levels[rk] {
                        if b.1 && lk == rk && a.expr > bb.expr {
                            continue;
                        }
                        let fa = a.f.clone();
                        let fb = bb.f.clone();
                        let op = b.2.clone();
                        let cand = Cand {
                            expr: format!("{}({}, {})", b.0, a.expr, bb.expr),
                            f: Arc::new(move |args| op(fa(args)?, fb(args)?)),
                            deps: a.deps | bb.deps,
                        };
                        if let Some(sig) = signature(&cand, arity, quotient_var_permutations) {
                            if !seen.contains_key(&sig) {
                                seen.insert(sig, cand.clone());
                                next.push(cand);
                            }
                        }
                    }
                }
            }
        }
        if k >= 4 {
            for t in ternary_ops() {
                if !gen_filter.allow_ternary(t.0) {
                    continue;
                }
                for a_k in 1..=k - 3 {
                    for b_k in 1..=k - 2 - a_k {
                        let c_k = k - 1 - a_k - b_k;
                        if c_k < 1 {
                            continue;
                        }
                        for a in &levels[a_k] {
                            for b in &levels[b_k] {
                                for c in &levels[c_k] {
                                    let fa = a.f.clone();
                                    let fb = b.f.clone();
                                    let fc = c.f.clone();
                                    let op = t.1.clone();
                                    let cand = Cand {
                                        expr: format!("{}({}, {}, {})", t.0, a.expr, b.expr, c.expr),
                                        f: Arc::new(move |args| op(fa(args)?, fb(args)?, fc(args)?)),
                                        deps: a.deps | b.deps | c.deps,
                                    };
                                    if let Some(sig) =
                                        signature(&cand, arity, quotient_var_permutations)
                                    {
                                        if !seen.contains_key(&sig) {
                                            seen.insert(sig, cand.clone());
                                            next.push(cand);
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        if next.len() > max_keep {
            discarded_by_cap += next.len() - max_keep;
            next.sort_by(|a, b| {
                let da = a.deps.count_ones() as usize;
                let db = b.deps.count_ones() as usize;
                db.cmp(&da)
                    .then_with(|| a.expr.len().cmp(&b.expr.len()))
                    .then_with(|| a.expr.cmp(&b.expr))
            });
            next.truncate(max_keep);
        }
        levels[k] = next;
    }

    let need = if arity == 0 { 0 } else { (1u8 << arity) - 1 };
    let total_unique_all_deps = seen.len();
    let mut out: Vec<Cand> = if require_full_deps {
        seen.into_values().filter(|c| c.deps == need).collect()
    } else {
        seen.into_values().collect()
    };
    out.sort_by(|a, b| a.expr.len().cmp(&b.expr.len()).then_with(|| a.expr.cmp(&b.expr)));
    GenOutput {
        pool: out,
        discarded_by_cap,
        total_unique_all_deps,
    }
}

fn can_represent(
    target: C,
    constants: &[C],
    unary: &[Unary],
    binary: &[Binary],
    ternary: &[Ternary],
    max_k: usize,
) -> bool {
    let mut levels: Vec<Vec<C>> = vec![vec![]; max_k + 1];
    let mut seen: HashMap<(i64, i64), bool> = HashMap::new();
    for &c in constants {
        if !c.is_finite() {
            continue;
        }
        let key = qkey(c);
        if seen.insert(key, true).is_none() {
            levels[1].push(c);
            if near(c, target) {
                return true;
            }
        }
    }
    for k in 2..=max_k {
        let mut next = Vec::new();
        for u in unary {
            for &x in &levels[k - 1] {
                if let Some(y) = (u.f)(x) {
                    if y.is_finite() {
                        let key = qkey(y);
                        if seen.insert(key, true).is_none() {
                            if near(y, target) {
                                return true;
                            }
                            next.push(y);
                        }
                    }
                }
            }
        }
        for b in binary {
            for lk in 1..k - 1 {
                let rk = k - 1 - lk;
                for &a in &levels[lk] {
                    for &bb in &levels[rk] {
                        if b.commutative && lk == rk && qkey(a) > qkey(bb) {
                            continue;
                        }
                        if let Some(y) = (b.f)(a, bb) {
                            if y.is_finite() {
                                let key = qkey(y);
                                if seen.insert(key, true).is_none() {
                                    if near(y, target) {
                                        return true;
                                    }
                                    next.push(y);
                                }
                            }
                        }
                    }
                }
            }
        }
        if k >= 4 {
            for t in ternary {
                for ak in 1..=k - 3 {
                    for bk in 1..=k - 2 - ak {
                        let ck = k - 1 - ak - bk;
                        if ck < 1 {
                            continue;
                        }
                        for &a in &levels[ak] {
                            for &b in &levels[bk] {
                                for &c in &levels[ck] {
                                    if let Some(y) = (t.f)(a, b, c) {
                                        if y.is_finite() {
                                            let key = qkey(y);
                                            if seen.insert(key, true).is_none() {
                                                if near(y, target) {
                                                    return true;
                                                }
                                                next.push(y);
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        levels[k] = next;
    }
    false
}

#[derive(Clone)]
struct Family {
    name: &'static str,
    const_targets: Vec<C>,
    unary_targets: Vec<Unary>,
    binary_targets: Vec<Binary>,
}

fn completeness_families() -> Vec<Family> {
    vec![
        Family {
            name: "S1_ExpLog_Subtract",
            const_targets: vec![],
            unary_targets: vec![
                Unary { f: Arc::new(|x| Some(x.exp())) },
                Unary { f: Arc::new(|x| x.ln()) },
            ],
            binary_targets: vec![Binary {
                f: Arc::new(|a, b| Some(a.sub(b))),
                commutative: false,
            }],
        },
        Family {
            name: "S2_E_Power_Log",
            const_targets: vec![C::real(std::f64::consts::E)],
            unary_targets: vec![],
            binary_targets: vec![
                Binary { f: Arc::new(|a, b| a.pow(b)), commutative: false },
                Binary {
                    f: Arc::new(|base, x| x.ln()?.div(base.ln()?)),
                    commutative: false,
                },
            ],
        },
        Family {
            name: "S3_Exp_LogBinary",
            const_targets: vec![],
            unary_targets: vec![Unary {
                f: Arc::new(|x| Some(x.exp())),
            }],
            binary_targets: vec![
                Binary {
                    f: Arc::new(|base, x| x.ln()?.div(base.ln()?)),
                    commutative: false,
                },
            ],
        },
        Family {
            name: "S4_Cosh_ArcCosh_Divide",
            const_targets: vec![],
            unary_targets: vec![
                Unary { f: Arc::new(|x| Some(x.cosh())) },
                Unary { f: Arc::new(|x| x.acosh()) },
            ],
            binary_targets: vec![Binary {
                f: Arc::new(|a, b| a.div(b)),
                commutative: false,
            }],
        },
        Family {
            name: "Wolfram_Mathematica",
            const_targets: vec![C::i()],
            unary_targets: vec![Unary {
                f: Arc::new(|x| x.ln()),
            }],
            binary_targets: vec![
                Binary {
                    f: Arc::new(|a, b| Some(a.add(b))),
                    commutative: true,
                },
                Binary {
                    f: Arc::new(|a, b| Some(a.mul(b))),
                    commutative: true,
                },
                Binary {
                    f: Arc::new(|a, b| a.pow(b)),
                    commutative: false,
                },
            ],
        },
    ]
}

fn satisfies_any_family(
    constants: &[C],
    unary: &[Unary],
    binary: &[Binary],
    ternary: &[Ternary],
    families: &[Family],
    k: usize,
) -> Option<&'static str> {
    for fam in families {
        let mut ok = true;
        for c in &fam.const_targets {
            if !can_represent(*c, constants, unary, binary, ternary, k) {
                ok = false;
                break;
            }
        }
        if !ok {
            continue;
        }
        for u in &fam.unary_targets {
            let Some(target) = (u.f)(C::real(EULER_GAMMA)) else {
                ok = false;
                break;
            };
            if !can_represent(target, constants, unary, binary, ternary, k) {
                ok = false;
                break;
            }
        }
        if !ok {
            continue;
        }
        for b in &fam.binary_targets {
            let Some(target) = (b.f)(C::real(EULER_GAMMA), C::real(GLAISHER)) else {
                ok = false;
                break;
            };
            if !can_represent(target, constants, unary, binary, ternary, k) {
                ok = false;
                break;
            }
        }
        if ok {
            return Some(fam.name);
        }
    }
    None
}

#[derive(Clone, Copy)]
struct RunProfiles {
    p0: bool,
    pa: bool,
    pb: bool,
    pc: bool,
}

impl RunProfiles {
    fn all() -> Self {
        Self {
            p0: true,
            pa: true,
            pb: true,
            pc: true,
        }
    }
}

fn parse_profiles() -> RunProfiles {
    let mut selected: Vec<String> = Vec::new();
    let argv: Vec<String> = env::args().skip(1).collect();
    let mut i = 0usize;
    while i < argv.len() {
        match argv[i].as_str() {
            "--profile" => {
                i += 1;
                if i < argv.len() {
                    selected.push(argv[i].clone());
                    i += 1;
                }
            }
            "--profiles" => {
                i += 1;
                if i < argv.len() {
                    selected.extend(
                        argv[i]
                            .split(',')
                            .map(str::trim)
                            .filter(|s| !s.is_empty())
                            .map(ToOwned::to_owned),
                    );
                    i += 1;
                }
            }
            _ => {
                i += 1;
            }
        }
    }

    if selected.is_empty() {
        return RunProfiles::all();
    }

    let mut out = RunProfiles {
        p0: false,
        pa: false,
        pb: false,
        pc: false,
    };
    for s in selected {
        match s.as_str() {
            "0" | "P0" | "p0" => out.p0 = true,
            "A" | "a" | "PA" | "pa" => out.pa = true,
            "B" | "b" | "PB" | "pb" => out.pb = true,
            "C" | "c" | "PC" | "pc" => out.pc = true,
            _ => {}
        }
    }
    out
}

fn parse_usize_flag(flag: &str, default_value: usize) -> usize {
    let argv: Vec<String> = env::args().skip(1).collect();
    let mut i = 0usize;
    while i < argv.len() {
        if argv[i] == flag {
            i += 1;
            if i < argv.len() {
                if let Ok(v) = argv[i].parse::<usize>() {
                    return v;
                }
            }
            return default_value;
        }
        i += 1;
    }
    default_value
}

fn parse_csv_flag(flag: &str) -> Option<Vec<String>> {
    let argv: Vec<String> = env::args().skip(1).collect();
    let mut i = 0usize;
    while i < argv.len() {
        if argv[i] == flag {
            i += 1;
            if i < argv.len() {
                let vals = argv[i]
                    .split(',')
                    .map(str::trim)
                    .filter(|s| !s.is_empty())
                    .map(ToOwned::to_owned)
                    .collect::<Vec<_>>();
                return Some(vals);
            }
            return Some(Vec::new());
        }
        i += 1;
    }
    None
}

fn parse_require_full_deps(default_value: bool) -> bool {
    let argv: Vec<String> = env::args().skip(1).collect();
    let mut out = default_value;
    for arg in argv {
        match arg.as_str() {
            "--allow-partial-deps" => out = false,
            "--require-full-deps" => out = true,
            _ => {}
        }
    }
    out
}

fn parse_quotient_var_permutations(default_value: bool) -> bool {
    let argv: Vec<String> = env::args().skip(1).collect();
    let mut out = default_value;
    for arg in argv {
        match arg.as_str() {
            "--no-quotient-var-permutations" => out = false,
            "--quotient-var-permutations" => out = true,
            _ => {}
        }
    }
    out
}

fn fmt_limit(v: usize) -> String {
    if v == usize::MAX {
        "All".to_string()
    } else {
        v.to_string()
    }
}

fn fmt_mma_expr(expr: &str) -> String {
    expr.replace('(', "[").replace(')', "]")
}

struct GenLanguageFilter {
    constants: Option<HashSet<String>>,
    unary: Option<HashSet<String>>,
    binary: Option<HashSet<String>>,
    ternary: Option<HashSet<String>>,
}

impl GenLanguageFilter {
    fn allow_const(&self, name: &str) -> bool {
        self.constants.as_ref().is_none_or(|s| s.contains(name))
    }
    fn allow_unary(&self, name: &str) -> bool {
        self.unary.as_ref().is_none_or(|s| s.contains(name))
    }
    fn allow_binary(&self, name: &str) -> bool {
        self.binary.as_ref().is_none_or(|s| s.contains(name))
    }
    fn allow_ternary(&self, name: &str) -> bool {
        self.ternary.as_ref().is_none_or(|s| s.contains(name))
    }
}

fn validate_name_filter(flag: &str, req: &Option<Vec<String>>, available: &[&str]) {
    let Some(req) = req else { return; };
    let avail: HashSet<&str> = available.iter().copied().collect();
    let unknown: Vec<String> = req
        .iter()
        .filter(|name| !avail.contains(name.as_str()))
        .cloned()
        .collect();
    if !unknown.is_empty() {
        let mut avail_sorted = available.to_vec();
        avail_sorted.sort_unstable();
        eprintln!("Error: unknown {} entries: {}", flag, unknown.join(", "));
        eprintln!("Available {} values: {}", flag, avail_sorted.join(", "));
        process::exit(2);
    }
}

fn parse_generation_language_filter() -> GenLanguageFilter {
    let const_req = parse_csv_flag("--gen-const");
    let unary_req = parse_csv_flag("--gen-unary");
    let binary_req = parse_csv_flag("--gen-binary");
    let ternary_req = parse_csv_flag("--gen-ternary");

    let const_avail: Vec<&str> = generation_seed_constants().iter().map(|(n, _)| *n).collect();
    let unary_avail: Vec<&str> = unary_ops().iter().map(|(n, _)| *n).collect();
    let binary_avail: Vec<&str> = binary_ops().iter().map(|(n, _, _)| *n).collect();
    let ternary_avail: Vec<&str> = ternary_ops().iter().map(|(n, _)| *n).collect();

    validate_name_filter("--gen-const", &const_req, &const_avail);
    validate_name_filter("--gen-unary", &unary_req, &unary_avail);
    validate_name_filter("--gen-binary", &binary_req, &binary_avail);
    validate_name_filter("--gen-ternary", &ternary_req, &ternary_avail);

    GenLanguageFilter {
        constants: const_req.map(|v| v.into_iter().collect()),
        unary: unary_req.map(|v| v.into_iter().collect()),
        binary: binary_req.map(|v| v.into_iter().collect()),
        ternary: ternary_req.map(|v| v.into_iter().collect()),
    }
}

fn selected_generation_names(filter: &GenLanguageFilter) -> (Vec<String>, Vec<String>, Vec<String>, Vec<String>) {
    let consts = generation_seed_constants()
        .into_iter()
        .map(|(n, _)| n.to_string())
        .filter(|n| filter.allow_const(n))
        .collect();
    let unary = unary_ops()
        .into_iter()
        .map(|(n, _)| n.to_string())
        .filter(|n| filter.allow_unary(n))
        .collect();
    let binary = binary_ops()
        .into_iter()
        .map(|(n, _, _)| n.to_string())
        .filter(|n| filter.allow_binary(n))
        .collect();
    let ternary = ternary_ops()
        .into_iter()
        .map(|(n, _)| n.to_string())
        .filter(|n| filter.allow_ternary(n))
        .collect();
    (consts, unary, binary, ternary)
}

fn select_families() -> Vec<Family> {
    let all = completeness_families();
    let include = parse_csv_flag("--families");
    let exclude = parse_csv_flag("--disable-families").unwrap_or_default();
    let available: HashSet<&'static str> = all.iter().map(|f| f.name).collect();

    if let Some(req) = &include {
        let unknown: Vec<String> = req
            .iter()
            .filter(|name| !available.contains(name.as_str()))
            .cloned()
            .collect();
        if !unknown.is_empty() {
            let mut avail_sorted: Vec<&str> = available.iter().copied().collect();
            avail_sorted.sort_unstable();
            eprintln!(
                "Error: unknown --families entries: {}",
                unknown.join(", ")
            );
            eprintln!("Available families: {}", avail_sorted.join(", "));
            process::exit(2);
        }
    }

    let include_set: Option<HashSet<String>> = include.map(|v| v.into_iter().collect());
    let exclude_set: HashSet<String> = exclude.into_iter().collect();

    all.into_iter()
        .filter(|f| {
            let included = match &include_set {
                Some(set) => set.contains(f.name),
                None => true,
            };
            included && !exclude_set.contains(f.name)
        })
        .collect()
}

fn main() {
    let start = Instant::now();
    let gen_k_default = 3usize;
    let gen_k_const_default = 1usize;
    let verify_k_default = 6usize;
    let max_keep_default = 100_000_000usize;
    let gen_k = parse_usize_flag("--gen-k", gen_k_default);
    let gen_k_const = parse_usize_flag("--gen-k-const", gen_k_const_default);
    let verify_k = parse_usize_flag("--verify-k", verify_k_default);
    let max_keep_per_level = parse_usize_flag("--max-keep-per-level", max_keep_default);
    let rayon_threads = parse_usize_flag("--rayon-threads", 0usize);
    let require_full_deps = parse_require_full_deps(true);
    let quotient_var_permutations = parse_quotient_var_permutations(true);
    let gen_filter = parse_generation_language_filter();
    let families = select_families();
    if rayon_threads > 0 {
        rayon::ThreadPoolBuilder::new()
            .num_threads(rayon_threads)
            .build_global()
            .expect("failed to initialize rayon global thread pool");
    }
    let effective_rayon_threads = rayon::current_num_threads();
    //Profile 0: 0 const, 1 unary, 1 binary
    let profile0_unary_take = usize::MAX;
    let profile0_binary_take = usize::MAX;
    //Profile A: 1 const, 0 unary, 1 binary
    let profile_a_const_take = usize::MAX;
    //let profile_a_binary_take = 120usize;
    let profile_a_binary_take = usize::MAX;
    //Profile B: 0 const, 0 unary, 1 binary
    let profile_b_binary_take = usize::MAX;
    //Profile C: 0 const, 0 unary, 0 binary, 1 ternary
    let profile_c_ternary_take = usize::MAX;
    let run = parse_profiles();
    println!(
        "Run config: gen_k={} gen_k_const={} verify_k={} max_keep_per_level={} require_full_deps={} quotient_var_permutations={} rayon_threads_request={} rayon_threads_effective={}",
        gen_k,
        gen_k_const,
        verify_k,
        max_keep_per_level,
        require_full_deps,
        quotient_var_permutations,
        if rayon_threads == 0 {
            "auto".to_string()
        } else {
            rayon_threads.to_string()
        },
        effective_rayon_threads
    );
    if families.is_empty() {
        println!("Enabled families: [] (no family checks can pass)");
    } else {
        let names: Vec<&str> = families.iter().map(|f| f.name).collect();
        println!("Enabled families: {:?}", names);
    }
    let (gen_consts, gen_unary, gen_binary, gen_ternary) = selected_generation_names(&gen_filter);
    println!(
        "Generation language: const={:?} unary={:?} binary={:?} ternary={:?}",
        gen_consts, gen_unary, gen_binary, gen_ternary
    );

    println!("Generating unnamed primitives...");
    let const_out = if run.pa {
        generate_candidates(
            0,
            gen_k_const,
            max_keep_per_level,
            require_full_deps,
            quotient_var_permutations,
            &gen_filter,
        )
    } else {
        empty_gen_output()
    };
    let unary_out = if run.p0 {
        generate_candidates(
            1,
            gen_k,
            max_keep_per_level,
            require_full_deps,
            quotient_var_permutations,
            &gen_filter,
        )
    } else {
        empty_gen_output()
    };
    let binary_out = if run.p0 || run.pa || run.pb {
        generate_candidates(
            2,
            gen_k,
            max_keep_per_level,
            require_full_deps,
            quotient_var_permutations,
            &gen_filter,
        )
    } else {
        empty_gen_output()
    };
    let ternary_out = if run.pc {
        generate_candidates(
            3,
            gen_k,
            max_keep_per_level,
            require_full_deps,
            quotient_var_permutations,
            &gen_filter,
        )
    } else {
        empty_gen_output()
    };
    let const_pool = const_out.pool;
    let unary_pool = unary_out.pool;
    let binary_pool = binary_out.pool;
    let ternary_pool = ternary_out.pool;
    println!(
        "Pool sizes: const={}, unary={}, binary={}, ternary={}",
        const_pool.len(),
        unary_pool.len(),
        binary_pool.len(),
        ternary_pool.len()
    );
    println!(
        "Profile limits: p0 unary={} binary={}, pA const={} binary={}, pB binary={}, pC ternary={}",
        fmt_limit(profile0_unary_take),
        fmt_limit(profile0_binary_take),
        fmt_limit(profile_a_const_take),
        fmt_limit(profile_a_binary_take),
        fmt_limit(profile_b_binary_take),
        fmt_limit(profile_c_ternary_take)
    );
    println!(
        "Discarded by cap(max_keep_per_level={}): const={}, unary={}, binary={}, ternary={}",
        max_keep_per_level,
        const_out.discarded_by_cap,
        unary_out.discarded_by_cap,
        binary_out.discarded_by_cap,
        ternary_out.discarded_by_cap
    );
    println!(
        "Unique before arity-dependency filter: const={}, unary={}, binary={}, ternary={}",
        const_out.total_unique_all_deps,
        unary_out.total_unique_all_deps,
        binary_out.total_unique_all_deps,
        ternary_out.total_unique_all_deps
    );
    println!(
        "Enabled profiles: 0={} A={} B={} C={}",
        run.p0, run.pa, run.pb, run.pc
    );

    let placeholder_constants = vec![C::real(EULER_GAMMA), C::real(GLAISHER)];
    let mut hits = 0usize;
    let mut hits_p0 = 0usize;
    let mut hits_pa = 0usize;
    let mut hits_pb = 0usize;
    let mut hits_pc = 0usize;

    if run.p0 {
        println!("Profile 0: 0 const, 1 unary, 1 binary");
        let p0_u_n = unary_pool.len().min(profile0_unary_take);
        let p0_b_n = binary_pool.len().min(profile0_binary_take);
        println!(
            "Profile 0 coverage: unary {} of {}, binary {} of {}, tested pairs {} of {}",
            p0_u_n,
            unary_pool.len(),
            p0_b_n,
            binary_pool.len(),
            p0_u_n.saturating_mul(p0_b_n),
            unary_pool.len().saturating_mul(binary_pool.len())
        );
        let has_exp = unary_pool.iter().any(|u| u.expr == "Exp(v0)");
        let has_log = binary_pool.iter().any(|b| b.expr == "Log(v0, v1)");
        if has_exp && has_log {
            let constants = vec![placeholder_constants[0], placeholder_constants[1]];
            let unary = vec![Unary {
                f: Arc::new(|x| Some(x.exp())),
            }];
            let binary = vec![Binary {
                f: Arc::new(|base, x| x.ln()?.div(base.ln()?)),
                commutative: false,
            }];
            if let Some(name) =
                satisfies_any_family(&constants, &unary, &binary, &[], &families, verify_k)
            {
                hits += 1;
                println!(
                    "ASSERTION HIT[{name}] unary={} | binary={}",
                    fmt_mma_expr("Exp(v0)"),
                    fmt_mma_expr("Log(v0, v1)")
                );
            } else {
                println!(
                    "ASSERTION FAILED: {}+{} not recognized",
                    fmt_mma_expr("Exp(v0)"),
                    fmt_mma_expr("Log(v0,v1)")
                );
            }
        } else {
            println!(
                "ASSERTION SKIPPED: missing generated primitive(s): has {}={}, has {}={}",
                fmt_mma_expr("Exp(v0)"),
                has_exp, has_log
                ,
                fmt_mma_expr("Log(v0,v1)")
            );
        }
        let unary_candidates: Vec<&Cand> = unary_pool.iter().take(profile0_unary_take).collect();
        let binary_candidates: Vec<&Cand> = binary_pool.iter().take(profile0_binary_take).collect();
        let p0_hits: Vec<(String, String, String)> = unary_candidates
            .par_iter()
            .map(|u| {
                let mut local_hits: Vec<(String, String, String)> = Vec::new();
                for b in &binary_candidates {
                    let constants = vec![placeholder_constants[0], placeholder_constants[1]];
                    let unary = vec![Unary {
                        f: Arc::new({
                            let f = u.f.clone();
                            move |x| f(&[x])
                        }),
                    }];
                    let binary = vec![Binary {
                        f: Arc::new({
                            let f = b.f.clone();
                            move |x, y| f(&[x, y])
                        }),
                        commutative: false,
                    }];
                    if let Some(name) = satisfies_any_family(
                        &constants,
                        &unary,
                        &binary,
                        &[],
                        &families,
                        verify_k,
                    ) {
                        local_hits.push((name.to_string(), u.expr.clone(), b.expr.clone()));
                    }
                }
                local_hits
            })
            .reduce(
                || Vec::new(),
                |mut acc, mut part| {
                    acc.append(&mut part);
                    acc
                },
            );
        let mut p0_hits_sorted = p0_hits;
        p0_hits_sorted.sort();
        for (name, unary_expr, binary_expr) in &p0_hits_sorted {
            println!(
                "HIT[{name}] unary={} | binary={}",
                fmt_mma_expr(unary_expr),
                fmt_mma_expr(binary_expr)
            );
        }
        hits_p0 += p0_hits_sorted.len();
        hits += p0_hits_sorted.len();
        println!("Profile 0 hits: {hits_p0}");
    }

    if run.pa {
        println!("Profile A: 1 const, 0 unary, 1 binary");
        let pa_c_n = const_pool.len().min(profile_a_const_take);
        let pa_b_n = binary_pool.len().min(profile_a_binary_take);
        println!(
            "Profile A coverage: const {} of {}, binary {} of {}, tested pairs {} of {}",
            pa_c_n,
            const_pool.len(),
            pa_b_n,
            binary_pool.len(),
            pa_c_n.saturating_mul(pa_b_n),
            const_pool.len().saturating_mul(binary_pool.len())
        );
        let const_candidates: Vec<(&Cand, C)> = const_pool
            .iter()
            .take(profile_a_const_take)
            .filter_map(|c| (c.f)(&[]).map(|cv| (c, cv)))
            .collect();
        let binary_candidates: Vec<&Cand> =
            binary_pool.iter().take(profile_a_binary_take).collect();
        let pa_hits: Vec<(String, String, String)> = const_candidates
            .par_iter()
            .map(|(c, cv)| {
                let mut local_hits: Vec<(String, String, String)> = Vec::new();
                for b in &binary_candidates {
                    let constants = vec![placeholder_constants[0], placeholder_constants[1], *cv];
                    let unary = vec![];
                    let binary = vec![Binary {
                        f: Arc::new({
                            let f = b.f.clone();
                            move |x, y| f(&[x, y])
                        }),
                        commutative: false,
                    }];
                    if let Some(name) =
                        satisfies_any_family(&constants, &unary, &binary, &[], &families, verify_k)
                    {
                        local_hits.push((name.to_string(), c.expr.clone(), b.expr.clone()));
                    }
                }
                local_hits
            })
            .reduce(
                || Vec::new(),
                |mut acc, mut part| {
                    acc.append(&mut part);
                    acc
                },
            );
        let mut pa_hits_sorted = pa_hits;
        pa_hits_sorted.sort();
        for (name, const_expr, binary_expr) in &pa_hits_sorted {
            println!(
                "HIT[{name}] const={} | binary={}",
                fmt_mma_expr(const_expr),
                fmt_mma_expr(binary_expr)
            );
        }
        hits_pa += pa_hits_sorted.len();
        hits += pa_hits_sorted.len();
        println!("Profile A hits: {hits_pa}");
    }

    if run.pb {
        println!("Profile B: 0 const, 0 unary, 1 binary");
        let pb_b_n = binary_pool.len().min(profile_b_binary_take);
        println!(
            "Profile B coverage: binary {} of {}",
            pb_b_n,
            binary_pool.len()
        );
        let binary_candidates: Vec<&Cand> = binary_pool.iter().take(profile_b_binary_take).collect();
        let pb_hits: Vec<(String, String)> = binary_candidates
            .par_iter()
            .filter_map(|b| {
                let constants = vec![placeholder_constants[0], placeholder_constants[1]];
                let unary = vec![];
                let binary = vec![Binary {
                    f: Arc::new({
                        let f = b.f.clone();
                        move |x, y| f(&[x, y])
                    }),
                    commutative: false,
                }];
                satisfies_any_family(&constants, &unary, &binary, &[], &families, verify_k)
                    .map(|name| (name.to_string(), b.expr.clone()))
            })
            .collect();
        let mut pb_hits_sorted = pb_hits;
        pb_hits_sorted.sort();
        for (name, binary_expr) in &pb_hits_sorted {
            println!("HIT[{name}] binary={}", fmt_mma_expr(binary_expr));
        }
        hits_pb += pb_hits_sorted.len();
        hits += pb_hits_sorted.len();
        println!("Profile B hits: {hits_pb}");
    }

    if run.pc {
        println!("Profile C: 0 const, 0 unary, 0 binary, 1 ternary");
        let pc_t_n = ternary_pool.len().min(profile_c_ternary_take);
        println!(
            "Profile C coverage: ternary {} of {}",
            pc_t_n,
            ternary_pool.len()
        );
        let ternary_candidates: Vec<&Cand> =
            ternary_pool.iter().take(profile_c_ternary_take).collect();
        let pc_hits: Vec<(String, String)> = ternary_candidates
            .par_iter()
            .filter_map(|t| {
                let constants = vec![placeholder_constants[0], placeholder_constants[1]];
                let ternary = vec![Ternary {
                    f: Arc::new({
                        let f = t.f.clone();
                        move |a, b, c| f(&[a, b, c])
                    }),
                }];
                satisfies_any_family(&constants, &[], &[], &ternary, &families, verify_k)
                    .map(|name| (name.to_string(), t.expr.clone()))
            })
            .collect();
        let mut pc_hits_sorted = pc_hits;
        pc_hits_sorted.sort();
        for (name, ternary_expr) in &pc_hits_sorted {
            println!("HIT[{name}] ternary={}", fmt_mma_expr(ternary_expr));
        }
        hits_pc += pc_hits_sorted.len();
        hits += pc_hits_sorted.len();
        println!("Profile C hits: {hits_pc}");
    }

    println!("Done. hits={hits}, elapsed={:.2?}", start.elapsed());
    
}
